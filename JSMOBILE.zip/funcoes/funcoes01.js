/**
 * FUNÇÕES: São blocos de código que podem ser reaproveitados
 * Funções podem ou não ter nomes
 * Podem ou não receber parâmetros
 */
// CRIAR OU DECLARAR FUNÇÕES
function dizOla(nome) {
  //código
  console.log('Olá! ' + nome)
}
// INVOCAR / CHAMAR FUNÇÕES
//dizOla('Pamela')
//dizOla('Thamily')
//dizOla('Manuella')

//ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(2, 3)
somaDoisNumeros(5, 6)
// SUBTRAÇÃO
function subtraiDoisNumeros(x, y) {
  const subtrai = x - y
  console.log(subtrai)
}
subtraiDoisNumeros(6, 5)
subtraiDoisNumeros(4, 2)
// MULTIPLICAÇÃO
function multiplicaDoisNumeros(x, y) {
  const multiplica = x * y
  console.log(multiplica)
}
multiplicaDoisNumeros(9,4)
multiplicaDoisNumeros(9, 6)

// DIVISÃO
function divideDoisNumeros(x, y) {
  const divide = x / y
  console.log(divide)

}
divideDoisNumeros(3, 8)
divideDoisNumeros(3, 5)






