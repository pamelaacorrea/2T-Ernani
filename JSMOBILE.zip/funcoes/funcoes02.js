// DECLARAÇÃO OU CRIAÇÃO
function soma(n1, n2) {
  if (typeof n1 === 'number' && typeof n2 === 'number') {
    const res = n1 + n2;
    alert('o resultado foi: ' + res)
  } else {
    alert(' Por favor insira um número válido')
  }
}
// INVOCAÇÃO OU CHAMAR 
soma(3, 5)
soma(5, 15)
soma(-3, 5)

function dados (nome, altura){
  if (typeof nome === 'string' && typeof altura === 'number'){
  const res = "olá" + nome + "sua altura é" + altura
alert ('o resultado foi: ' + res)
} else {
  alert (" Por favor insira um número válido")
}
}
dados("Pamela",1.70)
dados("Pamela", "Manu")

